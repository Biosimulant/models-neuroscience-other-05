From Excitatory and Inhibitory Interactions in Localized Populations of Model Neurons
Hugh R. Wilson and Jack D. Cowan; Biophys J. 1972 January; 12:1-24.

To run:
  nrnivmodl
  nrngui wc.hoc

Buttons marked 'slow' use movierun so as to allow the trajectory to be viewed
during the run. 

Parameters can be set in the PointProcessManager.  Then use 'As set' button to run
without resetting the parameters.

This implementation was copied from Bard Ermentrout's xppaut file: wc.ode
(included)
