An implementation of a model of a basket cell from the dentate gyrus of rat 
hippocampus that was used by Bartos, M., Vida, I., Frotscher, M., Geiger, 
J.R.P, and Jonas, P..  Rapid signaling at inhibitory synapses in a dentate 
gyrus interneuron network.  Journal of Neuroscience 21:2687-2698, 2001.  This 
implementation reproduces Figs. 5Ac and d in that paper.  The model contains 
no active currents.  If you have questions about this implementation, 
contact ted.carnevale@yale.edu
