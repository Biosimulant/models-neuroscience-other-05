

struct cblock	{
		int nnnn[3] ;
		double rcont[LRCONT] ;
		} ;

struct cblock cont_ ;

struct sblock	{
		int nfcn,njac,nstep,naccpt,nrejct,ndec,nsol;
		} ;

struct sblock stat_ ;
