load voltage.txt
plot(voltage(:,1),voltage(:,2),'r-');
hold on;
