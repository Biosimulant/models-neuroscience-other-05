function timedLog(str)
c = clock;
disp([sprintf('%02.0f',c(4)) ':' sprintf('%02.0f',c(5)) ' : '  str])    
