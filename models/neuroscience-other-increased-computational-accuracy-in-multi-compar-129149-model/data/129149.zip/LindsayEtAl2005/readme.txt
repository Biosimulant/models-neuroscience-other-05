This is the readme for model files associated with the paper:

Lindsay AE, Lindsay KA, Rosenberg JR (2005) Increased Computational
Accuracy in Multi-Compartmental Cable Models by a Novel Approach for
Precise Point Process Localization J Comp Neurosci 19:21-38

These files were contributed by Dr Jay Rosenberg.  Please refer to the
publication.

20140217 ModelDB Administrator: NeuronDriver.hoc was modified to run
10 rather than 2000 simulations since that was appropriate to the
amount of data supplied in CellData.dat.
