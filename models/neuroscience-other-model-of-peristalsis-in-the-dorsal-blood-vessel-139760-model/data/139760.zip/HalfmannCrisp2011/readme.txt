This is the readme for the model associated with the paper:

Halfmann K, Crisp K (2011) A Kinematic Study of Pulsation in the
Dorsal Blood Vessel of the blackworm, Lumbriculus variegatus
IMPULSE-An Undergraduate Journal for Neuroscience :1-10

This python model in Halfmann_Crisp_Model.py was contributed by Kameko
Halfmann.

The model requiress VPython, MatPlotLib, easygui and numpy modules.
