This is the readme for the model associated with the paper:

Burrell BD, Crisp KM (2008) Serotonergic modulation of
afterhyperpolarization in a neuron that contributes to learning in the
leech. J Neurophysiol 99(2):605-616

This is the SNNAP code that was used by the paper authors.
Please contact Kevin Crisp crisp at stolaf.edu for more info.
