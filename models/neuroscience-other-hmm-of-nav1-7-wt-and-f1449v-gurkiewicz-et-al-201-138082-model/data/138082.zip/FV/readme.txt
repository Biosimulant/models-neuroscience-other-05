These are the NEURON mod files associated with the paper:

Gurkiewicz M, Korngreen A, Waxman SG, Lampert A (2011) Kinetic
Modeling of Nav1.7 Provides Insight Into Erythromelalgia-associated
F1449V Mutation. J Neurophysiol

These files were contributed by Meron Gurkiewicz.
