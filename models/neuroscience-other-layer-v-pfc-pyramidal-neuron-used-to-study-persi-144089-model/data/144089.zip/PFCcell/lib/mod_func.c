#include <stdio.h>
modl_reg(){
	fprintf(stderr, "Additional mechanisms from files\n");

fprintf(stderr, "\n");
}
