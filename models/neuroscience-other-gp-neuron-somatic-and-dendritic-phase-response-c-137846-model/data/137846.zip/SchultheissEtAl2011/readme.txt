This is the model for the paper:

Schultheiss NW, Edgerton JR, Jaeger D (2010) Phase response curve
analysis of a full morphological globus pallidus neuron model reveals
distinct perisomatic and dendritic modes of synaptic integration
J. Neurosci. 30(7):2767-2782

These files were contributed by Dr Schultheiss.
