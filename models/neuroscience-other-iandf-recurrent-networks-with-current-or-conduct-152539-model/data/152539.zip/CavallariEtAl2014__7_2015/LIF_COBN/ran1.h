float ran1(long *idum);
