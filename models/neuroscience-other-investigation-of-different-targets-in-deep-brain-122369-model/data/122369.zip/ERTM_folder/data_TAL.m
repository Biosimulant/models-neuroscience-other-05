global gl_tal;
global el_tal;
global gna_tal;
global ena_tal;
global gk_tal;
global ek_tal;
global gt_tal;
global et_tal;
global c_tal;
global qht;
global tadj;
global apr;
global apt;


gl_tal=0.05;
el_tal=-70;
gna_tal=3;
ena_tal=50;
gk_tal=5;
ek_tal=-90;
gt_tal=5;
et_tal=0;
c_tal=1;

qht=5.5;
tadj=1;
apr=4;
apt=.3;