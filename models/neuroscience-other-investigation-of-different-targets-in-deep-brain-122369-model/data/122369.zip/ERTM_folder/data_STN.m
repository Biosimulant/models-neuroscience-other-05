gl_stn =2.25 ;
gk_stn =45.0 ;
gna_stn =37.5 ;
gt_stn =0.5 ;
gca_stn =0.5 ;
gahp_stn =9.0 ;

el_stn =-60.0 ;
ek_stn =-80.0 ;
ena_stn =55.0 ;
eca_stn =140.0 ;

c_stn=1;

tauh1_stn =500.0 ;
taun1_stn =100.0 ;
taur1_stn =17.5 ;
tauh0_stn =1.0 ;
taun0_stn =1.0 ;
taur0_stn =7.1 ;
phih_stn =0.75;
phin_stn =0.75;
phir_stn =0.5;
k1_stn =15.0;
kca_stn =22.5;
epsil_stn =3.75*10^-5;
thetam_stn =-30.0;
thetah_stn =-39.0;
thetan_stn =-32.0;
thetar_stn =-67.0;
thetaa_stn =-63.0;
thetab_stn =0.25;
thetas_stn =-39.0;
thetatauh_stn =-57.0;
thetataun_stn =-80.0;
thetataur_stn =68.0;
thetagh_stn =-39.0;

sigmam_stn =15.0;
sigmah_stn =-3.1;
sigman_stn =8.0;
sigmar_stn =-2.0;
sigmaa_stn =7.8;
sigmab_stn =-0.07;
sigmas_stn =8.0;
sigmatauh_stn =-3.0;
sigmataun_stn =-26.0;
sigmataur_stn =-2.2;
sigmagh_stn =8.0;

A_stn =5;
B_stn =1;
A_stngpi=1;
B_stngpi=.05;
theta_stn=30;

syn_stngpe_gain=.2;