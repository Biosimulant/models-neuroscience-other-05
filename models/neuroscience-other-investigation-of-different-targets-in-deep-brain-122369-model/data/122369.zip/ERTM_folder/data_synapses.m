gstngpe=.3;
estngpe=0;

ggpestn=.90;
egpestn=-100;

ggpegpe=.3; %parametro da modificarsi per ottenere parkinsonismo
egpegpe=-80;

gstngpi=.3;
estngpi=0;

ggpegpi=1;
egpegpi=-100;

ggpith=.06;
egpith=-85;