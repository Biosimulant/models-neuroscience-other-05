gl_gpe =.1; 
gk_gpe =30.0; 
gna_gpe =120; 
gt_gpe =.5 ;
gca_gpe =0.1; 
gahp_gpe =30.0 ;
el_gpe =-55.0 ;
ek_gpe =-80.0 ;
ena_gpe =55.0 ;
eca_gpe =120.0; 


c_gpe=1;

tauh1_gpe =.27 ;
taun1_gpe =.27 ;
tauh0_gpe =.05 ;
taun0_gpe =.05 ;
taur_gpe =30.0 ;
phih_gpe =0.05;
phin_gpe =0.1;
phir_gpe =1;
k1_gpe =30.0;
kca_gpe =15;
epsil_gpe =1*10^-4;
thetam_gpe =-37.0;
thetah_gpe =-58.0;
thetan_gpe =-50.0;
thetar_gpe =-70.0;
thetaa_gpe =-57.0;
thetas_gpe =-35.0;
thetatauh_gpe =-40.0;
thetataun_gpe =-40.0;
thetagh_gpe =-57.0;

sigmam_gpe =10.0;
sigmah_gpe =-12;
sigman_gpe =14.0;
sigmar_gpe =-2.0;
sigmaa_gpe =2;
sigmas_gpe =2;
sigmatauh_gpe =-12;
sigmataun_gpe =-12.0;
sigmagh_gpe =2.0;


A_gpe =2;
B_gpe =.08;
A_gpegpi=1;
B_gpegpi=.1;
theta_gpe=20;