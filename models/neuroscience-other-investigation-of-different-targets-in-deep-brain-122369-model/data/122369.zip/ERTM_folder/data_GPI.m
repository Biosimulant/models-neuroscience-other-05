gl_gpi =.1 ;
gk_gpi =30.0 ;
gna_gpi =120 ;
gt_gpi =.5 ;
gca_gpi =0.15; 
gahp_gpi =30.0; 
el_gpi =-55.0 ;
ek_gpi =-80.0 ;
ena_gpi =55.0 ;
eca_gpi =120.0; 


c_gpi=1;

tauh1_gpi =.27 ;
taun1_gpi =.27 ;
tauh0_gpi =.05 ;
taun0_gpi =.05 ;
taur_gpi =30.0 ;
phih_gpi =0.05;
phin_gpi =0.1;
phir_gpi =1;
k1_gpi =30.0;
kca_gpi =15;
epsil_gpi =1*10^-4;
thetam_gpi =-37.0;
thetah_gpi =-58.0;
thetan_gpi =-50.0;
thetar_gpi =-70.0;
thetaa_gpi =-57.0;
thetas_gpi =-35.0;
thetatauh_gpi =-40.0;
thetataun_gpi =-40.0;
thetagh_gpi =-57.0;

sigmam_gpi =10.0;
sigmah_gpi =-12;
sigman_gpi =14.0;
sigmar_gpi =-2.0;
sigmaa_gpi =2;
sigmas_gpi =2;
sigmatauh_gpi =-12;
sigmataun_gpi =-12.0;
sigmagh_gpi =2.0;

A_gpi =2;
B_gpi =.08;
theta_gpi=20;

A_gpe =2;
B_gpe =.08;
A_gpegpi=1;
B_gpegpi=.1;
theta_gpe=20;

A_stn =5;
B_stn =1;
A_stngpi=1;
B_stngpi=.05;
theta_stn=30;