This is the readme for the code for the paper:

Beverlin B, Kakalios J, Nykamp D, Netoff TI (2011) Dynamical changes
in neurons during seizures determine tonic to clonic shift. J Comput
Neurosci

These files are from B Beverlin.

Usage:

Included is the code for running the Tonic-clonic simulation
(ML_depress_sim.m) and the code for running the many network
simulations (ML_Net_Sweep.m). In addition, the user will need the
derivative file (ML_derivs.m).


