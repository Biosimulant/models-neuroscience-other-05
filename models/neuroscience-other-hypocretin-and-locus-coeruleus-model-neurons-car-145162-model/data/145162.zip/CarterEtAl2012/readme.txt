This is the readme associated with the model for the paper:

Carter ME, Brill J, Bonnavion P, Huguenard JR, Huerta R, de Lecea, L (2012)
Mechanism for Hypocretin-mediated sleep-to-wake transitions PNAS

Please see the HOWTOINSTALL file for installation on a linux (ubuntu) platform.

These model files were supplied by Ramon Huerta.
