Readme for Morris-Lecar model of the barnacle giant muscle fiber 1981

This model was implemented by Evyatar Av-Ron from the publication

Morris C, Lecar H (1981) Voltage oscillations in the barnacle giant muscle fiber. Biophys J 35:193-213


to use:

Download and expand the zip file into a directory that contains no spaces in it's path.
Double click on the SNNAP8.jar file in the SNNAP directory.  Click on Run Simulation, then
on the new window click File --> Load Simulation and select the available file.  Finally
click on ml.smu and then Start.  The simulation produced shows the model running in the
oscillatory mode.
