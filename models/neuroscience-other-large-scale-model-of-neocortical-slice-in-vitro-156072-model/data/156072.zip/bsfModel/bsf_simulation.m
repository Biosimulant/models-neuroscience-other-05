SS.parallelSim = true;
SS.timeStep = 0.03125;
SS.simulationTime = 2400;
SS.poolSize = 12;
SS.profileName = 'local';
SS.spikeLoad = false;