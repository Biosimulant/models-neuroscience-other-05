These are the model files associated with the publications:

Edin F, Macoveanu J, Olesen P, Tegner J, Klingberg T (2007) Stronger
synaptic connectivity as a mechanism behind development of working
memory-related brain activity during childhood. J Cogn Neurosci
19:750-60

Edin F et al. J Integr Neurosci. 2007 Dec.

These files were supplied by Fredrik Edin.
