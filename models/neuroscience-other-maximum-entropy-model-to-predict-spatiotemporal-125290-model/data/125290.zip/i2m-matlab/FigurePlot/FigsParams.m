%General default parameters for figures

MarkovColor = [0 1 0];
IsingColor = [1 0 0];
NoCorrColor = [0 0 1];
FtSize = 14;
FtLabelSize = 16;
Nor = 1/log(10);