DataFigures='Figures/';
path(path,[pwd,'/Common']);
path(path,[pwd,'/Glauber']);
path(path,[pwd,'/InfoTools']);
path(path,[pwd,'/Surrogate']);
path(path,[pwd,'/FigurePlot']);
path(path,[pwd,'/LoadRaster']);
