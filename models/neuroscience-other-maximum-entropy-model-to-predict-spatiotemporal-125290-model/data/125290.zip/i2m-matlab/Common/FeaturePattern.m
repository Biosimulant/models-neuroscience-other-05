function nb=FeaturePattern(pattern)
nb=sum(sum((pattern+1)/2));
