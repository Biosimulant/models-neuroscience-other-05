exec(compile(open('izhiGUI.py', "rb").read(), 'izhiGUI.py', 'exec'))
