gp1scale_0.asc represents uniform synaptic conductance amplitudes.
gp1scale_1.asc is the set of weights attained from the last run of the
	iterative weight-balancing scheme used 12/17/2004, and so is the most
	balanced weight set for the older version of the model.

