After the data from NEURON is generated, these .m files can be used with MATLAB to 
open and sort these files into more useful vectors and matrices.  It is recommended 
that the generated .dat files be in the same directory or in a subdirectory as the 
.m files.  Instructions for their use are in comments in their respective codes.

velsetupfirst.m and velsetupnext.m are used to sort the 2-parameter velocity data.
voltsetup.m is used to sort the voltage data.