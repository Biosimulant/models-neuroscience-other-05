This is a readme for the model and data analysis files for the paper:

Young RG, Castelfranco AM, Hartline DK (2013) The "Lillie transition":
models of the onset of saltatory conduction in myelinating axons. J
Comput Neurosci 34:533-46

Please see the readme's in the NEURON and MATLAB folders.  You will
need to run NEURON first, then MATLAB.
