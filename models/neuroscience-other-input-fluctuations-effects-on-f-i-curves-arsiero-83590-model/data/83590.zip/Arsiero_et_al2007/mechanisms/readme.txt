This directory contains the mechanisms needed by the simulation.

Ifluct1.mod		Fluctuating current

hh_in.mod		Squid sodium (slow inactivating), potassium, 
                        and leak channels

The user needs to compile such mechanisms to use them in NEURON
(i.e. run mknrndll.exe on windows, or refer to the NEURON
documentation).

Jan 8th, 2007 - Arsiero, M., Luescher, H.-R., Lundstrom, B.N., and
Giugliano, M.
