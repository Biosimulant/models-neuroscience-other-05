%
%
%

g = load('G.x');
plot(g(:,1), g(:,2:end));