%
%
%

sample = load('sample.x');
plot(sample(:,1), sample(:,2), sample(:,1), sample(:,4));

% subplot(3,2,1);
% for k=1:6,
%  subplot(3,2,2*k-1);
%  plot(sample(:,1), sample(:,2*k-1+1))
% 
%  subplot(3,2,2*k);
%  plot(sample(:,1), sample(:,2*k+1))
% end
