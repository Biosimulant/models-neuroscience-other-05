This model is associated with a paper that was just accepted by coauthor
Michele Giugliano.  Michele will supply the complete citation soon.
