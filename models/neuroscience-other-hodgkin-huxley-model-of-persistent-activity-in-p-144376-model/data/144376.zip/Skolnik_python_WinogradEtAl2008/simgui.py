from pyinit import *
h.xopen("simgui.hoc")
