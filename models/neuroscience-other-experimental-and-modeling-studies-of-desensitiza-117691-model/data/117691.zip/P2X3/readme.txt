This is the readme for the model associated with the paper:

Sokolova E, Skorinkin A, Moiseev I, Agrachev A, Nistri A, Giniatullin R (2006)
Experimental and modeling studies of desensitization of P2X3 receptors.
Mol Pharmacol 70:373-82

These model files were supplied by Dr Andrei Skorinkin.

Usage notes:

These model files require Delphi 6 or greater.  Start with the file

DS_especial.dpr
