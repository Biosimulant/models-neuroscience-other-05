This is the readme for the model associated with the paper:

Almog M, Korngreen A (2014) A Quantitative Description of Dendritic
Conductances and Its Application to Dendritic Excitation in Layer 5
Pyramidal Neurons J Neurosci 34(1):182-196

This is the NEURON code the authors used.  NEURON is freely available
at http://www.neuron.yale.edu

To run demo compile the mod files (mknrndll (mswin and mac) or
nrnivmodl (linux/unix) start cc_run.hoc with the method appropriate to
your platform (double click (mswin),drag and drop onto nrngui icon
(mac) or "nrngui cc_run.hoc" on the command line (unix/linux).

Changelog
=========

* 20220924: Update MOD files to avoid declaring variables and functions with the same name.
  See https://github.com/neuronsimulator/nrn/pull/1992

