%
% script to plot simulation data: raster plot only
%
%	$Revision:$
% 

%nn_pars = zeros(3,1);
plot_raster_graph(FN, sim, offset, sim.T_upd);

