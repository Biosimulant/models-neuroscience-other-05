%
% 	script to plot simulation data with up to 5 neurons
%	* input
%	* raster plot
%	* spike diagram
%	
%	$Revision:$

nn_pars = zeros(3,1);
%plot_sr_AHP(FN, sim, nn_inputs, 1, nn_pars,offset);
plot_sr_AHP_int(FN, sim, nn_inputs, 1, nn_pars,offset);

