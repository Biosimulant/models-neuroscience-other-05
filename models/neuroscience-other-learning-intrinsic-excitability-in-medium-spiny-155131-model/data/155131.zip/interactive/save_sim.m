%
% script for saving the entire sim
%
%	$Revision:$

save(sprintf('%s_all.mat',FN));

fprintf('Entire Simulation saved.\n');

