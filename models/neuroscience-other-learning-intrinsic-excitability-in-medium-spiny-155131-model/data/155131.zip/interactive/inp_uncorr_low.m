%
% parameters for low uncorrelated input
%
%	$Revision:$

input_params.Mp = 100;  	% Mp
input_params.lambdap = 100;  	% lambda_p
input_params.g0 = -3;	% g_0

input_params_inh.Mn = 20;  	% Mn
input_params_inh.Mp = 0;  	% Mp
input_params_inh.lambdan = 40;  	% lambda_n
input_params_inh.g0 = -3;	% g_0

