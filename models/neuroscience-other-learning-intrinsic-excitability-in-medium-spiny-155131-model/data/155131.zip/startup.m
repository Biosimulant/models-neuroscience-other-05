
NEURO_MATLAB=pwd;

path(path,[NEURO_MATLAB filesep 'analysis']);
path(path,[NEURO_MATLAB filesep 'ch_analysis']);
path(path,[NEURO_MATLAB filesep 'gain_filter']);
path(path,[NEURO_MATLAB filesep 'gui']);
path(path,[NEURO_MATLAB filesep 'input']);
path(path,[NEURO_MATLAB filesep 'input_analysis']);
path(path,[NEURO_MATLAB filesep 'interactive']);
path(path,[NEURO_MATLAB filesep 'netsim']);
path(path,[NEURO_MATLAB filesep 'neuron']);
path(path,[NEURO_MATLAB filesep 'syn_response']);
