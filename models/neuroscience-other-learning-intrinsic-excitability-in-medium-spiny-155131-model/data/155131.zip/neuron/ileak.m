% leak current
%
%	$Revision:$
%
function I_L= leak(V_m)

I_L = 0.04 * (V_m - -75);	


