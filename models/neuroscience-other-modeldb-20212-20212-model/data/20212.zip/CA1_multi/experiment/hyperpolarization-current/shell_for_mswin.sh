# to run on the pc type the following lines:
export HOC_LIBRARY_PATH=/tmp/CA1/template
export NEURONHOME=c:/nrn56
# and then start up with 
c:/nrn56/bin/neuron -dll /tmp/CA1/mechanism/nrnmech.dll H_current.hoc
