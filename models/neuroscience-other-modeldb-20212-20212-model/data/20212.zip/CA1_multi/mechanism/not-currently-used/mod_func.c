#include <stdio.h>
modl_reg(){
	fprintf(stderr, "Additional mechanisms from files\n");

fprintf(stderr," ca.mod");
fprintf(stderr," cal.mod");
fprintf(stderr," can2.mod");
fprintf(stderr," cat.mod");
fprintf(stderr," d3.mod");
fprintf(stderr," gabaa.mod");
fprintf(stderr," gabab.mod");
fprintf(stderr," glutamate.mod");
fprintf(stderr," h.mod");
fprintf(stderr," hh3.mod");
fprintf(stderr," hh3_flei.mod");
fprintf(stderr," hha.mod");
fprintf(stderr," kadist.mod");
fprintf(stderr," kaprox.mod");
fprintf(stderr," kca.mod");
fprintf(stderr," kdr.mod");
fprintf(stderr," kdrca1.mod");
fprintf(stderr," na3.mod");
fprintf(stderr," nax.mod");
fprintf(stderr," nmda.mod");
fprintf(stderr, "\n");
_ca_reg();
_cal_reg();
_can2_reg();
_cat_reg();
_d3_reg();
_gabaa_reg();
_gabab_reg();
_glutamate_reg();
_h_reg();
_hh3_reg();
_hh3_flei_reg();
_hha_reg();
_kadist_reg();
_kaprox_reg();
_kca_reg();
_kdr_reg();
_kdrca1_reg();
_na3_reg();
_nax_reg();
_nmda_reg();
}
