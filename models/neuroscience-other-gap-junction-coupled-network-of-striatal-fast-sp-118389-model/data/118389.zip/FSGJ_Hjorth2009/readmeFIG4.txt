For figure 4A,B,C simply execute the matlab script runAllFig4sims in
the FIG4 directory.

Resulting figures can be found in the FIG4/FIGS directory:

FIG4-TraceA-GJ.eps
FIG4-TraceA-NC.eps
FIG4-TraceB-GJ.eps
FIG4-TraceB-NC.eps
FIG4-TraceC-GJ.eps
FIG4-TraceC-NC.eps


For figure 4D, go into FIG3 directory and use the data previously
generated there to make figure.

Matlab scripts to read and process data (OBS, in FIG3 directory!!):
readTenFSGJscanAllUpstate
countSpikeApperanceDisappearanceCONDVAR

Resulting figure:
countSpikeApperanceDisappearance-condVar.fig
