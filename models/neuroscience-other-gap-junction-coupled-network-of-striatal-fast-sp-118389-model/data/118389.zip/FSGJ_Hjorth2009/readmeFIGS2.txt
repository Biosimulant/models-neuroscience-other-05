The files needed to generate Figure S2 are in the FIGS2/ directory.

Many of the simulations in this paper take alot of time, this one is quick!

To run the simulation:
runOneFSsaveAMPAGABAcond.m

To generate the figures:
plotCondFigs.m

