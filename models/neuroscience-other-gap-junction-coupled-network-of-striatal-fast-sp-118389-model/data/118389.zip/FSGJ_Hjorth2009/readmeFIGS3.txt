The scripts to generate Figure S3A and S3B are in FIGS3

Run the following matlab scripts:

Run simulations:
runTenInhomoFSGJcorrVariationJITTERSaveGJcur.m

Read data:
readTenInhomoFSJITTERWithGJcur.m

Make the frequency curves:
makeTenInhomoFScorrVarJITTER.m

Make current through GJ figs:
makeSpikeCenteredGJcurPlotJITTER.m

