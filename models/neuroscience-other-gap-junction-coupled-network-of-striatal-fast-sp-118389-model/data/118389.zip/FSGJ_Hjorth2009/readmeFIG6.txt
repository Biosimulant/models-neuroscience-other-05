The scripts for Figure 6 are shared with FIG3, hence why FIG6 is just
a symbolic link to the FIG3 directory.


Figure 6A:

runTenFShigherFreqLessShunting.m
readHigherFreqLessShuntingData.m
makeHigherFreqLessShuntingPlot.m


Figure 6B:
runTenFShigherFreqLessShuntingSaveGJcur.m
readHigherFreqLessShuntingDataSavedGJcur.m
makeGJvoltageDiffPlot.m


Figure 6C: 
runTenFShigherFreqLessShuntingSaveGJcur.m   (same as in 6B)
readHigherFreqLessShuntingDataSavedGJcur.m
makeSpikeCenteredGJcurPlot.m
makeSpikeCenteredGJcurPlotLONGER


Figure 6D:
readHigherFreqLessShuntingData
countSpikeApperanceDisappearanceFREQVAR.m


Figure 6E:
readHigherFreqLessShuntingDataSavedGJcur
makeFIG6spikePairsOnePairCLEAN
