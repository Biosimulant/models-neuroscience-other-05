For supplementary material figure S4A

Cur inject -- freq figure
/home/hjorth/genesis/fsCurInputInhomogeneNetwork


runTenFScurInejctInhomogeneNetworkGJscan.m
readTenFSGJscanInjectCur.m
makeTenFS3dGJscanPlotcurInject.m

or

makeTenFSGJscanPlotCurInject


Figure:
freqSpikes-STDerr-curinject.fig

_______________

For figure S4B

plotCurInjectExampleTraces

You will have to change the path in the script to the directory where
you have the datafiles.

In my case it was:, but yours will be different.
/home/hjorth/genesis/fsCurInputInhomogeneNetwork/UTDATA/SAVED/TenFSGJscanCurInject/shorter
