Figure 2A and 2B

This figure just exemplifies the change in spiking when two neurons go
from uncoupled to coupled, by adding gap junctions. Any voltage trace
outputted from the other scripts will do.

Voltage traces can be loaded from any of the simulations using:

d = load('yourdatafilehere.data');
plot(d(:,1),d(:,2:end));

________________________

Figure 2C

runTwoFS.m

readTwoFS.m
makeTwoFS2dSynchSpikeFreqPlotFIG2Cprop

Output file:
TwoFS-synchSpikePairs-AllPairs-GJ-1-prop.fig


_____________________


Figure 2D

runTwoFSupstateDownstate.m
readTwoFSupstateDownstate.m
makeTwoFSJPSTH.m


