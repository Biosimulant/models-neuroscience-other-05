
Figure 3A

Run matlab script:
runTenInhomoFSGJscanAllUpstateStandard.m

Scripts to analys:
readTenFSAllupstateDataStandard.m
makeFIG3standardCrossCorrelogramAllInOneFINER.m

Figur:
TenFS-allUpstateStandard-RAWcc-AllInOneFINER.eps


_______________


Figure 3B, 3C

Matlab scripts:

runTenInhomoFSGJscanAllUpstate

readTenFSGJscanAllUpstate
makeFIG3spikePairs

