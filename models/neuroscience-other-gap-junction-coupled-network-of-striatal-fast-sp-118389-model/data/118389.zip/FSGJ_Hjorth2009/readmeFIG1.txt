Figure 1A

FIG1A

Run script in matlab:
runIFscanTenFS
readIFscanTenFS
makeIFplots


_________________


Figure 1B

3D visualisation of neuron not included.


_________________


Figure 1C

Directory:
FIG1C

Run script in matlab:
runGapEffCalibratePRIMshorterPulse

Figure:
FIG1/A/UTDATA/SAVED/ShorterPules/fsGalCalibrate.eps



_________________


Figure 1D

Visualisation of network, byproduct of other scripts.
