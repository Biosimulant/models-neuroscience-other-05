#!/usr/bin/env python
execfile('py/common.py')
execfile('py/figures2_S5.py')
# Figure 2
f2S5plot(90,190,2)
# Figure S5
f2S5plot(90,150,8)
