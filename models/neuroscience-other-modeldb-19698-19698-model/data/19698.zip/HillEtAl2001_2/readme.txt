This is the readme for the GENESIS models associated with the papers:

1 . Hill AA, Masino MA, Calabrese RL (2002) Model of intersegmental
coordination in the leech heartbeat neuronal network. J Neurophysiol
87:1586-602 [PubMed]

2 . Hill AA, Lu J, Masino MA, Olsen OH, Calabrese RL (2001) A model of
a segmental oscillator in the leech heartbeat neuronal network. J
Comput Neurosci 10:281-302

These models were previously available at a Calabrese lab web
site. The files are now available here where the contents of these tar
files are present in these folders

HN-NET.tar          HN-net/
leech-libraries.tar leech-libraries/
tutorial.tar        Calabrese/

Please refer to the readme's in the folders for more information.
