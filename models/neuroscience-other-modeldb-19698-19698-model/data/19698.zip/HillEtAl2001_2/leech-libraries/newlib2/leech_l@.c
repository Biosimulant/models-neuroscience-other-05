LIBRARY_leech()
{
LibraryHeader("leech","Wed Nov  3 17:12:13 1999 ");DATA_leech();
STARTUP_leech();
}
