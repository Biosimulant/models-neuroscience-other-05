#define SynS_object_VOLTAGE 0
#define SynG_object_VOLTAGE 0
#define SynG_object_CAF 1
#define SynG_object_CAS 2
#define SynG_object_POSTVOLTAGE 3
