#define newspikegen_INPUT 0
#define newspikegen_THRESH 1
