LIBRARY_newconnlib()
{
LibraryHeader("newconnlib","Wed Nov  3 17:12:09 1999 ");DATA_newconnlib();
STARTUP_newconnlib();
}
