#!/bin/bash

scripts/figure4b.py
scripts/figure7ab.py
