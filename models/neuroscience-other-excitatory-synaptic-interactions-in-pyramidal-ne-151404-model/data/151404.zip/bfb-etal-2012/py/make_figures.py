#!/usr/bin/env python
execfile('py/common.py')
execfile('py/figure4b.py')
execfile('py/figure4d.py')
execfile('py/figure7ab.py')
