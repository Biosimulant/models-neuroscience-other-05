function [final] = sDAP (t,a)
final=t*exp(-t/a)/a;
end

