function [ a ] = dendriteRefractoryPeriod(D, E, b)
a=D+E*b;
end

