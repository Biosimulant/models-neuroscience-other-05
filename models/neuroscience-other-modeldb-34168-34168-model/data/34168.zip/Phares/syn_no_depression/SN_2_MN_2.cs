		>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
		>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
		>>    modules name: cs		>>
		>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
		>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

		>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
Ics:		> 	Current due to a chemical synapse		>
		>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

>------------------------------->--------------------------------------->
>				>	    _				>
	1			>	G= (g+R) x fAt 		(1)	>
/syn_no_depression/SN_2_MN.fAt 	>fAt<	>  time-dependent activation		>
/syn_no_depression/cs.R	          >R<	>  random fluctuations			>
	0.14	   >0.1 g uS<	>					>
	30.0       >30 E mV<	>	Ics= G x (V -E)			>
>				>					>
>------------------------------->--------------------------------------->
>				>	    _				>
>	2			>	G= (g+R) x fAvt 	(2)	>
>   filename.fAvt 	>fAvt<	>  time- & voltage-dependent activation >
>   filename.R	        >R<	>  random fluctuations			>
>	xxx.xx  	>g uS<	>					>
>	xxx.xx  	>E mV<	>	Ics= G x (V -E)			>
>				>					>
>------------------------------->--------------------------------------->

END:
