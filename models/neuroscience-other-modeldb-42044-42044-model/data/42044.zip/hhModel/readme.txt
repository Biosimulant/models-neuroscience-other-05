This implementation of HH in SNAPP was provided by Evyatar Av-Ron <eav-ron@uth.tmc.edu>

To run:

Download and unzip the zip file into a directory that has no spaces in its path.

Double click on the SNNAP8.jar file (where the 8 might be a different version)

Click on start simulation, then File--> Load simulation and select the hh.smu file.

Finally click on start.
