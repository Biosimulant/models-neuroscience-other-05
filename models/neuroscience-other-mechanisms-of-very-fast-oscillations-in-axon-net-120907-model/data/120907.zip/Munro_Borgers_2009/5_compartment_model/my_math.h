/* This file is for my own math-helper functions which seems to be missing/
   or not functioning as expected. */

#include <math.h>
#include <limits.h>
#define PI 3.14159265358979

double min(double a, double b);
int my_round(double x);
unsigned long factorial(int);
