void connections(int conn[][4],int,int,double,double);
int coord_to_index(int,int,int,int);
int* index_to_coord(int,int,int,int*);
