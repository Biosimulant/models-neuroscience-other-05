[x, t, S, sol, PAR] = eldiff;
plotarticle(x, t, sol, PAR);