function out = radToDeg(in)
%
%
%

out = 180 .* in ./ pi;