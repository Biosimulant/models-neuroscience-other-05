function out = degToRad(in)
%
%
%

out = pi .* in ./ 180;