This is the model associated with a conference paper:

Teresa A. Murray (2007) Model of long-range transmission of gamma
oscillation. SaD1.29 650-653 Proceedings of the 3rd International IEEE
EMBS Conference on Neural Engineering Kohala Coast, Hawaii, May 2-5

There is also a longer student paper supplied in the archive files.
These files were supplied by Teresa Murray.

This model2x2PulsedCA1ECMay1_2005.mdl file is a matlab file that can
be directly opened and run with simulink.
