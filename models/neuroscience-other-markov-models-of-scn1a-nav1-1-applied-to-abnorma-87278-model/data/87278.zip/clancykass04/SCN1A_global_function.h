/*
 *  SCN1A_global_function.h
 *  
 *
 *  Created by Colleen Clancy on Wed Jan 29 2003.
 *  Copyright (c) 2003 __MyCompanyName__. All rights reserved.
 *
 */

#include <Carbon/Carbon.h>

double Na_MC3, Na_MC, Na_MO, Na_MI, Na_MIs, Na_MC2, IC3, IC2, Na_MIs2, M_C3, M_C2, M_C, M_O, M_OP, Na_OP, Na_O, OPs, M_IF;
